package com.example.categorycrud;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText editTextCategoryName;
    Button buttonAdd, buttonUpdate, buttonDelete;
    ListView listViewCategories;

    DatabaseReference databaseCategories;
    ArrayList<Category> categoryList;
    Category selectedCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        databaseCategories = FirebaseDatabase.getInstance().getReference("categories");

        editTextCategoryName = findViewById(R.id.editTextCategoryName);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonDelete = findViewById(R.id.buttonDelete);
        listViewCategories = findViewById(R.id.listViewCategories);

        categoryList = new ArrayList<>();

        buttonAdd.setOnClickListener(v -> {
            String name = editTextCategoryName.getText().toString().trim();
            if (!name.isEmpty()) {
                addCategory(name);
            } else {
                Toast.makeText(MainActivity.this, "Please enter category name", Toast.LENGTH_SHORT).show();
            }
        });

        buttonUpdate.setOnClickListener(v -> {
            if (selectedCategory != null) {
                String newName = editTextCategoryName.getText().toString().trim();
                if (!newName.isEmpty()) {
                    updateCategory(selectedCategory.getId(), newName);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter new category name", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonDelete.setOnClickListener(v -> {
            if (selectedCategory != null) {
                deleteCategory(selectedCategory.getId());
            }
        });

        listViewCategories.setOnItemClickListener((parent, view, position, id) -> {
            selectedCategory = categoryList.get(position);
            editTextCategoryName.setText(selectedCategory.getName());
            buttonUpdate.setEnabled(true);
            buttonDelete.setEnabled(true);
        });


        getCategories();
    }

    private void addCategory(String name) {
        String id = databaseCategories.push().getKey();
        Category category = new Category(id, name);

        databaseCategories.child(id).setValue(category).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(MainActivity.this, "Category added successfully", Toast.LENGTH_SHORT).show();
                editTextCategoryName.setText("");
            } else {
                Toast.makeText(MainActivity.this, "Failed to add category", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getCategories() {
        databaseCategories.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                categoryList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Category category = dataSnapshot.getValue(Category.class);
                    categoryList.add(category);
                }
                ArrayAdapter<Category> adapter = new ArrayAdapter<>(MainActivity.this,
                        android.R.layout.simple_list_item_1, categoryList);
                listViewCategories.setAdapter(adapter);


                selectedCategory = null;
                editTextCategoryName.setText("");
                buttonUpdate.setEnabled(false);
                buttonDelete.setEnabled(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Failed to load categories", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateCategory(String id, String newName) {
        databaseCategories.child(id).child("name").setValue(newName).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(MainActivity.this, "Category updated successfully", Toast.LENGTH_SHORT).show();
                editTextCategoryName.setText("");
                selectedCategory = null;
                buttonUpdate.setEnabled(false);
                buttonDelete.setEnabled(false);
            } else {
                Toast.makeText(MainActivity.this, "Failed to update category", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteCategory(String id) {
        databaseCategories.child(id).removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(MainActivity.this, "Category deleted successfully", Toast.LENGTH_SHORT).show();
                editTextCategoryName.setText("");
                selectedCategory = null;
                buttonUpdate.setEnabled(false);
                buttonDelete.setEnabled(false);
            } else {
                Toast.makeText(MainActivity.this, "Failed to delete category", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
